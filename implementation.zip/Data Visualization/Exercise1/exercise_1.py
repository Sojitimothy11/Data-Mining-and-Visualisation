import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
import seaborn as sns

# Load the data
df = pd.read_csv('djia.csv')

# Display basic info and first few rows
print("Data Info:")
print(df.info())
print("\nFirst 5 rows:")
print(df.head())

# Check for missing values
print("\nMissing values:")
print(df.isnull().sum())


# Load and preprocess data
df = pd.read_csv('djia.csv')
df['Date'] = pd.to_datetime(df['Date'], format='%d/%m/%Y')

# Calculate summary statistics
summary_stats = df['Price'].describe()
print("Summary Statistics:")
print(summary_stats)

# Visualisation 1: Box Plot
plt.figure(figsize=(10, 6))
sns.boxplot(x=df['Price'])
plt.title('Box Plot of DJIA Price (1914–1968)')
plt.xlabel('Price')
plt.savefig('box_plot.png')

# Visualisation 2: Violin Plot
plt.figure(figsize=(10, 6))
sns.violinplot(x=df['Price'])
plt.title('Violin Plot of DJIA Price (1914–1968)')
plt.xlabel('Price')
plt.savefig('violin_plot.png')

# Visualisation 3: Line Chart
plt.figure(figsize=(12, 6))
plt.plot(df['Date'], df['Price'], label='Price')
plt.title('DJIA Price Over Time (1914–1968)')
plt.xlabel('Year')
plt.ylabel('Price')
plt.grid(True)
plt.savefig('line_chart.png')

# Task 5: Line of Best Fit
# Create a numeric x-axis (x = range(0, 649))
x = np.arange(len(df))
y = df['Price'].values
# Compute coefficients with np.polyfit(x, y, 1)
coeffs = np.polyfit(x, y, 1)
poly = np.poly1d(coeffs)
best_fit_line = poly(x)

plt.figure(figsize=(12, 6))
plt.plot(df['Date'], df['Price'], label='DJIA Price')
plt.plot(df['Date'], best_fit_line, color='red',
         linestyle='--', label='Line of Best Fit')
plt.title('DJIA Price with Line of Best Fit (1914–1968)')
plt.xlabel('Year')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.savefig('trend_line.png')

# Task 6: Temporal Anomaly Detection
# Use rolling mean and standard deviation to identify potential anomalies
window = 12  # 12-month rolling window
df['Rolling Mean'] = df['Price'].rolling(window=window).mean()
df['Rolling Std'] = df['Price'].rolling(window=window).std()

# Define anomaly threshold (e.g., 2 standard deviations)
df['Upper Band'] = df['Rolling Mean'] + (2 * df['Rolling Std'])
df['Lower Band'] = df['Rolling Mean'] - (2 * df['Rolling Std'])
df['Anomaly'] = (df['Price'] > df['Upper Band']) | (
    df['Price'] < df['Lower Band'])

plt.figure(figsize=(12, 6))
plt.plot(df['Date'], df['Price'], label='Price', color='blue', alpha=0.5)
plt.plot(df['Date'], df['Rolling Mean'],
         label='Rolling Mean (12-mo)', color='green')
plt.fill_between(df['Date'], df['Lower Band'], df['Upper Band'],
                 color='gray', alpha=0.2, label='Confidence Interval')
plt.scatter(df[df['Anomaly']]['Date'], df[df['Anomaly']]
            ['Price'], color='red', label='Anomaly', zorder=5)
plt.title('Temporal Anomaly Detection in DJIA (1914–1968)')
plt.xlabel('Year')
plt.ylabel('Price')
plt.legend()
plt.grid(True)
plt.savefig('anomaly_detection.png')

# Specifically check months 180-220 for anomalies
# Month indices in Python start from 0
anomaly_subset = df.iloc[180:221]
anomalies_in_range = anomaly_subset[anomaly_subset['Anomaly']]
print("\nAnomalies between months 180-220:")
print(anomalies_in_range[['Date', 'Price']])
